export class CreateBookDto {
    title: string;
    author: string;
    genre: string;
}