import { Controller, Get, Post, Put, Param, Body, Delete, Patch } from '@nestjs/common';  // import HTTP decorators
import { BooksService } from './books.service';
import { CreateBookDto } from './book-dto';


@Controller('books')  // route prefix: all routed start with /books
export class BooksController {
    constructor(private booksService: BooksService){} // inject the service

    @Get() // GET books
    getAllBooks() {
        return this.booksService.getBooks(); // call service to get all books
    }

    @Get('id') // GET /books/:id
    getBook(@Param('id')id:string) {
        return this.booksService.getBookById(Number(id)); // convert id o number and fetch book
    }

    @Post() // POST aka add book
    addBook(@Body() bookDto: CreateBookDto) {
        return this.booksService.addBook(bookDto); // call service to add book 
    }

    @Delete('id') //DELETE /books/:id
    deleteBook(@Param('id') id: string) {
        return this.booksService.deleteBook(Number(id)); // convert id to number and delete
    } 

    @Put('id') // PUT (replace existing resource completely) book by id
    updateBook(@Param('id') id: string, @Body() updatedBook: any) {
        return this.booksService.updateBook(Number(id), updatedBook);
    }
}
