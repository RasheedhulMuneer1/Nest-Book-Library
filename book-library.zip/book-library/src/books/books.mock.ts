export const BOOKS = [
    {id: 1, title: "Atomic Habits", author: "James Clear", genre: "Psychology"},
    {id: 2, title: "Power of your subconcious mind", author: "andrew", genre: "Psychology"},
    {id: 3, title: "Psychology od Money", author: "Margon Housel", genre: "Finance"},
    {id: 4, title: "Lateral Thinking", author: "Edward de borno", genre: "Psychology"},
    {id: 5, title: "Clarity of thinking", author: "Hal Mooz", genre: "Psychology"},
    {id: 6, title: "The history of violence", author: "David", genre: "Comics"},
    {id: 7, title: "Queit: The power of introverts", author: "Goggins", genre: "Personality Development"}


];