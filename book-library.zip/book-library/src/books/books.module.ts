import { Module } from '@nestjs/common';  // imports @Module decorator
import { BooksController } from './books.controller';  // imports controller
import { BooksService } from './books.service';  // imports service

@Module({
  controllers: [BooksController], // register controller in this module
  providers: [BooksService]  // register the service as a provider
})
export class BooksModule {}  // export module to use in app.module.ts
