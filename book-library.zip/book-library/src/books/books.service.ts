import { Injectable } from '@nestjs/common';  // makes this class as a provider that can be injected
import { BOOKS } from './books.mock';
import { CreateBookDto } from './book-dto';

@Injectable()
export class BooksService {
    private books = BOOKS; // assign mock data to a local var

    // return all books
    getBooks() {
        return this.books;
    }

    // return a book by id
    getBookById(id: number) {
        return this.books.find(c => c.id === id);  // finds the 1st book with mactching id
    }


    // add a new book
    addBook(bookDto: CreateBookDto) {
        const newBook = {
            id: this.books.length + 1, // assign new id based on array length
            ...bookDto // spread operator to copy title, author, genre from DTO
        };
        this.books.push(newBook); // add to the array
        return newBook; // return the newly added book
    }

    // delete book by id
    deleteBook(id: number) {
        const index = this.books.findIndex(book => book.id === id); // find the index of book
        if(index !== -1) {
            return this.books.splice(index, 1); // remove and return deleted book
        }
        return null; // if not found, return null
    }

    // update book by id
    updateBook(id: number, updateBook: any) {
        const index = this.books.findIndex(b => b.id === id);
        if (index !== -1) {
            this.books[index] = { id, ...updateBook } ; // replace the book
            return this.books[index];
        }
        return null;
    }

    // update book by id (partial)
    patchBook(id: number, partialBook: any) {
        const index = this.books.findIndex(b => b.id === id);
        if(index !== -1) {
            this.books[index] = { ...this.books[index], ...partialBook};
            return this.books[index];
        }
        return null;
    }
}
 

